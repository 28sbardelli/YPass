import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const projectRoot = path.resolve(path.dirname(__filename), '..');
const outputRoot = path.join(projectRoot, 'build', 'portable-runtime');

if (process.platform !== 'win32') {
  console.error('Build the portable Windows EXE on Windows so the bundled Node runtime is node.exe.');
  process.exit(1);
}

const npmExecPath = process.env.npm_execpath;
if (!npmExecPath || !fs.existsSync(npmExecPath)) {
  throw new Error('Could not locate npm-cli.js. Run this script through an npm command (npm run dist:portable).');
}

const npmRoot = path.resolve(path.dirname(npmExecPath), '..');
const npmCli = path.join(npmRoot, 'bin', 'npm-cli.js');
if (!fs.existsSync(npmCli)) throw new Error(`npm CLI was not found at ${npmCli}`);

const sourcePackage = JSON.parse(await fsp.readFile(path.join(projectRoot, 'package.json'), 'utf8'));
const runtimePackage = {
  name: sourcePackage.name,
  version: sourcePackage.version,
  private: true,
  type: 'module',
  engines: sourcePackage.engines,
  dependencies: sourcePackage.dependencies || {},
};

await fsp.rm(outputRoot, { recursive: true, force: true });
const appOutput = path.join(outputRoot, 'app');
const nodeOutput = path.join(outputRoot, 'node');
await fsp.mkdir(appOutput, { recursive: true });
await fsp.mkdir(nodeOutput, { recursive: true });

for (const name of ['app.js', 'src', 'public']) {
  await fsp.cp(path.join(projectRoot, name), path.join(appOutput, name), { recursive: true });
}
await fsp.writeFile(path.join(appOutput, 'package.json'), `${JSON.stringify(runtimePackage, null, 2)}\n`);
await fsp.copyFile(process.execPath, path.join(nodeOutput, 'node.exe'));
await fsp.cp(npmRoot, path.join(nodeOutput, 'npm'), { recursive: true });

console.log(`Prepared portable application files in ${outputRoot}`);
console.log(`Bundled Node: ${process.version}`);
console.log(`Bundled npm: ${JSON.parse(await fsp.readFile(path.join(npmRoot, 'package.json'), 'utf8')).version}`);
console.log(`Runtime dependencies: ${Object.keys(runtimePackage.dependencies).length}`);
