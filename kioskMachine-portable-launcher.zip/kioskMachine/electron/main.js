import { app, BrowserWindow, dialog, powerSaveBlocker, session } from 'electron';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadConfig } from '../src/config.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const HOST = '127.0.0.1';
const hasSingleInstanceLock = app.requestSingleInstanceLock();
let mainWindow;
let splashWindow;
let kioskProcess;
let kioskOrigin;
let isQuitting = false;
let powerBlockerId;
let recoveryAttempts = 0;
let recoveryTimer;
let childRestartTimer;
let launcherLogPath;

if (!hasSingleInstanceLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow && !mainWindow.isDestroyed()) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    } else if (splashWindow && !splashWindow.isDestroyed()) {
      splashWindow.focus();
    }
  });
}

function log(message) {
  const line = `[${new Date().toISOString()}] ${message}\n`;
  try { fs.appendFileSync(launcherLogPath, line); } catch {}
}

function configureStartup() {
  if (process.platform !== 'win32') return;
  const configured = process.env.KIOSK_START_ON_LOGIN;
  const openAtLogin = configured == null
    ? app.isPackaged
    : !['0', 'false', 'no', 'off'].includes(configured.toLowerCase());
  const launchPath = process.env.PORTABLE_EXECUTABLE_FILE || process.execPath;
  app.setLoginItemSettings({ openAtLogin, path: launchPath, args: ['--kiosk-autostart'] });
}

function safeOrigin(value) {
  try { return new URL(value).origin; } catch { return ''; }
}

function showSplash() {
  splashWindow = new BrowserWindow({
    width: 520,
    height: 250,
    resizable: false,
    movable: true,
    minimizable: false,
    maximizable: false,
    frame: false,
    alwaysOnTop: true,
    show: true,
    backgroundColor: '#0f172a',
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true },
  });
  splashWindow.loadFile(path.join(__dirname, 'boot.html'));
}

function setSplashStatus(message) {
  if (!splashWindow || splashWindow.isDestroyed()) return;
  const safeMessage = JSON.stringify(String(message));
  splashWindow.webContents.executeJavaScript(
    `document.getElementById('status').textContent = ${safeMessage};`,
  ).catch(() => {});
}

async function prepareRuntime() {
  const bundledRoot = path.join(process.resourcesPath, 'portable-runtime');
  const bundledApp = path.join(bundledRoot, 'app');
  const nodeExecutable = path.join(bundledRoot, 'node', process.platform === 'win32' ? 'node.exe' : 'node');
  const npmCli = path.join(bundledRoot, 'node', 'npm', 'bin', 'npm-cli.js');
  if (!fs.existsSync(bundledApp) || !fs.existsSync(nodeExecutable) || !fs.existsSync(npmCli)) {
    throw new Error('The portable Node.js runtime is missing. Rebuild the portable EXE using the project build instructions.');
  }

  const runtimeDir = path.join(app.getPath('userData'), 'application');
  const markerPath = path.join(runtimeDir, '.kiosk-runtime-version');
  const version = app.getVersion();
  let installedVersion = '';
  try { installedVersion = (await fsp.readFile(markerPath, 'utf8')).trim(); } catch {}

  if (installedVersion !== version || !fs.existsSync(path.join(runtimeDir, 'app.js'))) {
    setSplashStatus('Preparing YPass Kiosk Machine…');
    await fsp.rm(runtimeDir, { recursive: true, force: true });
    await fsp.mkdir(runtimeDir, { recursive: true });
    await fsp.cp(bundledApp, runtimeDir, { recursive: true });
    await fsp.writeFile(markerPath, version, 'utf8');
  }

  setSplashStatus('Checking and installing application dependencies…');
  log(`Running npm install in ${runtimeDir}`);
  await runCommand(nodeExecutable, [
    npmCli,
    'install',
    '--omit=dev',
    '--no-audit',
    '--no-fund',
    '--no-progress',
  ], {
    cwd: runtimeDir,
    env: {
      ...process.env,
      PATH: `${path.dirname(nodeExecutable)}${path.delimiter}${process.env.PATH || ''}`,
      npm_config_update_notifier: 'false',
      npm_config_audit: 'false',
      npm_config_fund: 'false',
    },
    log,
  });

  return { runtimeDir, nodeExecutable };
}

function runCommand(command, args, { cwd, env, log: writeLog }) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { cwd, env, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    let output = '';
    child.stdout.on('data', (chunk) => {
      const value = chunk.toString();
      output += value;
      writeLog(value.trimEnd());
    });
    child.stderr.on('data', (chunk) => {
      const value = chunk.toString();
      output += value;
      writeLog(value.trimEnd());
    });
    child.once('error', reject);
    child.once('exit', (code) => {
      if (code === 0) resolve();
      else reject(new Error(`Dependency installation failed (exit code ${code}).\n${output.slice(-5000)}`));
    });
  });
}

function startKioskProcess(runtime) {
  const appEntry = path.join(runtime.runtimeDir, 'app.js');
  const env = {
    ...process.env,
    KIOSK_DATA_DIR: app.getPath('userData'),
    KIOSK_HOST: HOST,
  };
  const executable = app.isPackaged
    ? runtime.nodeExecutable
    : (process.env.npm_node_execpath || 'node');
  kioskProcess = spawn(executable, [appEntry], {
    cwd: runtime.runtimeDir,
    env,
    windowsHide: true,
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  kioskProcess.stdout?.on('data', (chunk) => log(chunk.toString().trimEnd()));
  kioskProcess.stderr?.on('data', (chunk) => log(`Kiosk stderr: ${chunk.toString().trimEnd()}`));
  kioskProcess.once('error', (error) => log(`Kiosk process error: ${error.message}`));
  kioskProcess.once('exit', (code, signal) => {
    log(`Kiosk process exited (code=${code}, signal=${signal})`);
    kioskProcess = null;
    if (!isQuitting) scheduleKioskProcessRestart(runtime);
  });
}

function scheduleKioskProcessRestart(runtime) {
  if (childRestartTimer || isQuitting) return;
  const delay = Math.min(1000 * (2 ** Math.min(recoveryAttempts, 5)), 30000);
  recoveryAttempts += 1;
  childRestartTimer = setTimeout(async () => {
    childRestartTimer = null;
    if (isQuitting) return;
    try {
      setSplashStatus('Restarting the local kiosk service…');
      startKioskProcess(runtime);
      await waitForKioskServer();
      recoveryAttempts = 0;
      if (mainWindow && !mainWindow.isDestroyed()) await mainWindow.loadURL(kioskOrigin);
      else await createKioskWindow();
    } catch (error) {
      log(`Kiosk service restart failed: ${error.message}`);
      scheduleKioskProcessRestart(runtime);
    }
  }, delay);
}

async function waitForKioskServer(timeoutMs = 45000) {
  const startedAt = Date.now();
  let lastError;
  while (Date.now() - startedAt < timeoutMs) {
    if (!kioskProcess) throw new Error('The local kiosk service stopped before it became ready.');
    try {
      const response = await fetch(kioskOrigin, { signal: AbortSignal.timeout(2500) });
      if (response.ok) return;
    } catch (error) {
      lastError = error;
    }
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  throw new Error(`The local kiosk service did not become ready. ${lastError?.message || ''}`);
}

function installPermissionPolicy() {
  session.defaultSession.setPermissionCheckHandler((_webContents, permission, requestingOrigin) => {
    return permission === 'media' && requestingOrigin === kioskOrigin;
  });
  session.defaultSession.setPermissionRequestHandler((webContents, permission, callback, details) => {
    const requestingOrigin = details?.requestingUrl ? safeOrigin(details.requestingUrl) : '';
    const wantsCamera = permission === 'media' && details?.mediaTypes?.includes('video');
    callback(Boolean(webContents && wantsCamera && requestingOrigin === kioskOrigin));
  });
}

async function createKioskWindow() {
  if (isQuitting) return;
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    show: false,
    kiosk: true,
    fullscreen: true,
    autoHideMenuBar: true,
    backgroundColor: '#0f172a',
    title: 'YPass Kiosk',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false,
      devTools: !app.isPackaged,
    },
  });

  mainWindow.setMenu(null);
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (safeOrigin(url) === kioskOrigin) {
      setImmediate(() => {
        if (mainWindow && !mainWindow.isDestroyed()) mainWindow.loadURL(url).catch(() => {});
      });
    }
    return { action: 'deny' };
  });
  mainWindow.webContents.on('before-input-event', (event, input) => {
    if (input.type !== 'keyDown') return;
    const key = input.key.toLowerCase();
    const ctrl = input.control || input.meta;
    const blockedShortcut = key === 'f12' || (ctrl && ['r', 'w', 'n', 'p', 's'].includes(key)) ||
      (ctrl && input.shift && ['i', 'j', 'c'].includes(key));
    if (blockedShortcut) event.preventDefault();
  });
  mainWindow.webContents.on('will-navigate', (event, targetUrl) => {
    if (safeOrigin(targetUrl) !== kioskOrigin) event.preventDefault();
  });
  mainWindow.webContents.on('will-attach-webview', (event) => event.preventDefault());
  mainWindow.webContents.on('render-process-gone', () => scheduleRendererRecovery());
  mainWindow.webContents.on('did-fail-load', (_event, errorCode, _description, validatedURL, isMainFrame) => {
    if (isMainFrame && errorCode !== -3 && safeOrigin(validatedURL) === kioskOrigin) scheduleRendererRecovery();
  });
  mainWindow.on('close', (event) => { if (!isQuitting) event.preventDefault(); });
  mainWindow.once('ready-to-show', () => {
    recoveryAttempts = 0;
    mainWindow?.show();
    if (splashWindow && !splashWindow.isDestroyed()) splashWindow.close();
    splashWindow = null;
  });
  mainWindow.on('closed', () => { mainWindow = null; });
  await mainWindow.loadURL(kioskOrigin);
}

function scheduleRendererRecovery() {
  if (isQuitting || recoveryTimer) return;
  recoveryAttempts += 1;
  const delay = Math.min(1000 * (2 ** Math.min(recoveryAttempts - 1, 5)), 30000);
  recoveryTimer = setTimeout(async () => {
    recoveryTimer = null;
    if (isQuitting) return;
    try {
      if (!mainWindow || mainWindow.isDestroyed()) await createKioskWindow();
      else await mainWindow.loadURL(kioskOrigin);
    } catch { scheduleRendererRecovery(); }
  }, delay);
}

app.whenReady().then(async () => {
  if (!hasSingleInstanceLock) return;
  const userDataPath = path.join(app.getPath('appData'), 'YPass Kiosk Machine');
  app.setPath('userData', userDataPath);
  await fsp.mkdir(userDataPath, { recursive: true });
  process.env.KIOSK_DATA_DIR = userDataPath;
  process.env.KIOSK_HOST = HOST;
  launcherLogPath = path.join(userDataPath, 'launcher.log');
  app.setAppUserModelId('org.ypass.kioskmachine');
  showSplash();

  try {
    const config = loadConfig();
    configureStartup();
    const port = config.port || 4177;
    kioskOrigin = `http://${HOST}:${port}`;
    installPermissionPolicy();

    let runtime;
    if (app.isPackaged) {
      runtime = await prepareRuntime();
    } else {
      runtime = { runtimeDir: path.resolve(__dirname, '..'), nodeExecutable: process.env.npm_node_execpath || 'node' };
    }

    setSplashStatus('Starting the local kiosk service…');
    startKioskProcess(runtime);
    await waitForKioskServer();
    powerBlockerId = powerSaveBlocker.start('prevent-display-sleep');
    await createKioskWindow();
  } catch (error) {
    log(`Startup failed: ${error.stack || error.message || error}`);
    dialog.showErrorBox(
      'YPass Kiosk Machine could not start',
      `${error?.message || error}\n\nLauncher log: ${launcherLogPath || 'not available'}`,
    );
    app.quit();
  }
});

app.on('activate', () => {
  if (!mainWindow && kioskOrigin && kioskProcess) createKioskWindow().catch(scheduleRendererRecovery);
});

app.on('before-quit', () => {
  isQuitting = true;
  if (recoveryTimer) clearTimeout(recoveryTimer);
  if (childRestartTimer) clearTimeout(childRestartTimer);
  if (powerBlockerId !== undefined && powerSaveBlocker.isStarted(powerBlockerId)) powerSaveBlocker.stop(powerBlockerId);
  if (kioskProcess && !kioskProcess.killed) kioskProcess.kill();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
