# YPass Kiosk Machine — Portable Electron Launcher

This project builds a **single portable Windows `.exe`**. It is not an installer and does not require Node.js or npm to be installed on the kiosk computer.

When the EXE is launched, Electron:

1. Creates the per-user YPass Kiosk Machine data directory.
2. Copies the kiosk's Node.js application files into that writable directory.
3. Runs the bundled Node.js and npm with `npm install --omit=dev --no-audit --no-fund` for the kiosk application.
4. Starts the kiosk's local Node.js server.
5. Opens the local kiosk page in a fullscreen Electron window.

The npm install runs on each launch so that the runtime dependencies declared by the kiosk application's `package.json` are present. The current kiosk backend uses Node.js built-in modules only, so the runtime dependency list is currently empty. The old `formbar-app-boilerplate: file:..` dependency has been removed; the kiosk is self-contained and can be built outside the YPass repository.

## Requirements to build the EXE

Build the portable Windows EXE on a Windows development computer with:

- Node.js 20 or newer
- npm (included with the Node.js installation)
- Internet access for npm to download Electron/build dependencies

The EXE itself bundles a copy of the build computer's `node.exe` and npm CLI. The target kiosk computer does **not** need a separate Node.js/npm installation.

## Build the portable EXE

Open PowerShell in this `kioskMachine` directory and run:

```powershell
npm ci
npm test
npm run dist:portable
```

The output is:

```text
release/YPass-Kiosk-Machine-1.0.0-Portable.exe
```

Copy that EXE to the kiosk computer and double-click it. It extracts its packaged resources, performs the application dependency check/install, starts the local server, and opens the kiosk window. No NSIS installer is generated.

> The portable EXE is built for Windows. `npm run prepare:portable` intentionally refuses to copy a non-Windows Node binary into a Windows application. Build it on Windows rather than Linux/macOS.

## Configure the central YPass server

Before first launch, create this file on the kiosk computer:

```text
%APPDATA%\YPass Kiosk Machine\.env
```

Example:

```env
KIOSK_SERVER_URL=https://your-ypass-server.example
KIOSK_PORT=4177
KIOSK_HEARTBEAT_MS=30000
KIOSK_START_ON_LOGIN=false
```

Replace the URL with the actual reachable YPass server address. Do not use `localhost` unless YPass is running on the same computer. The portable launcher defaults `KIOSK_START_ON_LOGIN` to enabled if the setting is omitted; set it to `false` if you only want to launch it manually. This is a per-Windows-user startup entry, not a Windows shell replacement.

The launcher stores its private data here:

```text
%APPDATA%\YPass Kiosk Machine\
```

This directory contains the kiosk configuration/secret, the copied runtime application, and `launcher.log`. Do not share or commit it. The kiosk's `kiosk-config.json` contains its secret.

## Development mode

For development on a computer that already has Node.js installed:

```powershell
npm ci
npm test
npm start
```

Development mode launches Electron and starts the local `app.js` with the Node.js executable available on PATH. It does not run a second `npm install` inside the source checkout, because that would prune Electron's development/build dependencies.

To run the local HTTP app without Electron:

```powershell
npm run start:node
```

## What this does not do

- It does not create an MSI/NSIS installer.
- It does not replace or terminate `explorer.exe`.
- It does not configure Windows Shell Launcher or Assigned Access.
- It does not install Node.js system-wide. It carries a private Node/npm runtime for this application.
- It does not change YPass server routes or pass business logic.

For Windows desktop replacement, configure Shell Launcher/Assigned Access separately through school IT. Do not use a forced `taskkill /f /im explorer.exe` workaround as a substitute.

## Logs and troubleshooting

Launcher and npm output are written to:

```text
%APPDATA%\YPass Kiosk Machine\launcher.log
```

If startup fails, check that file, confirm the kiosk computer can reach the YPass URL, and confirm outbound access to the npm registry is allowed on first launch. The first launch may take longer because npm checks/installs dependencies.

Run the automated tests with:

```powershell
npm test
```
