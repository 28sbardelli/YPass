@echo off
setlocal
cd /d "%~dp0"

echo ==========================================
echo   YPass Kiosk Machine - Portable EXE Build
echo ==========================================

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed. Install Node.js 20 or newer first.
  pause
  exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
  echo ERROR: npm was not found. Reinstall Node.js with npm included.
  pause
  exit /b 1
)

echo.
echo [1/3] Installing build dependencies...
npm ci
if errorlevel 1 goto failed

echo.
echo [2/3] Running tests...
npm test
if errorlevel 1 goto failed

echo.
echo [3/3] Building portable Windows EXE...
npm run dist:portable
if errorlevel 1 goto failed

echo.
echo SUCCESS. The portable EXE is in the release folder.
explorer "%~dp0release"
pause
exit /b 0

:failed
echo.
echo BUILD FAILED. Review the error above.
pause
exit /b 1
